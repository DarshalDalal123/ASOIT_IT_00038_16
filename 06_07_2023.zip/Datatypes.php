<!DOCTYPE html>
<html>
<body>

<?php 
$x = "Hello world!";
$y = 'Hello world!';
echo "String <br>";
echo $x;
echo "<br>"; 
echo $y;
echo "<br>";
$x = 5985;
var_dump($x);
echo "<br>";
$x = 10.365;
var_dump($x);
echo "<br>";
$cars = array("Volvo","BMW","Toyota");
var_dump($cars);
?>

</body>
</html>
