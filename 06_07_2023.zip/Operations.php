<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php
$x = 10.5;
$y = 5;
$sum = $x + $y;
$sub = $x - $y;
$mul = $x * $y;
$div = $x / $y;
echo "$x + $y = $sum";
echo "$x - $y = $sub";
echo "$x * $y = $mul";
echo "$x / $y = $div";
?> 

</body>
</html>
