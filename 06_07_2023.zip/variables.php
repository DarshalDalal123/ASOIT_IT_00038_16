<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php
$hello = "Hello World";
$txt = "Gaming";
$x = 5;
$y = 10.5;
echo "$hello is a string";
echo "<br>";
echo "$x is a integer";
echo "<br>";
echo "$y is a float variable";
echo "I love " . $txt . "!";
?> 

</body>
</html>